# TRStore Mail

Painel web + API REST + SMTP para caixas `@trstore.com`.

## Rodar

1. Copie `.env.example` para `.env`.
2. Troque todos os valores `CHANGE_ME`.
3. Execute:

```bash
docker compose up -d --build
```

Abra `http://SEU_IP:3000`.

## GitHub

```bash
git init
git add .
git commit -m "TRStore Mail"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/trstore-mail.git
git push -u origin main
```

Nunca envie `.env` para o GitHub.

## Domínio e recebimento

Para receber e-mails reais, aponte o DNS do `trstore.com` para o servidor. Exemplo:

```text
mail.trstore.com  A   IP_DO_SERVIDOR
trstore.com       MX  10 mail.trstore.com
```

O servidor SMTP deste projeto escuta na porta 2525 internamente. Em produção, normalmente você fará o encaminhamento da porta pública 25 para 2525, ou colocará um MTA/relay na frente. Configure também SPF, DKIM e DMARC.

## Acesso

A página inicial é o painel. O login usa `ADMIN_USER` e `ADMIN_PASSWORD` do `.env`.

Depois de entrar, clique em **Criar e-mail**, informe `suporte`, por exemplo, e será criada a caixa:

`suporte@trstore.com`

As mensagens recebidas aparecem automaticamente na caixa correspondente.

## Produção

Use HTTPS com um reverse proxy (Caddy/Nginx), firewall, backups do PostgreSQL e credenciais fortes. O painel é administrativo e deve ficar protegido.
