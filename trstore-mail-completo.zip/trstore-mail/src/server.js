import "dotenv/config";
import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {SMTPServer} from "smtp-server";
import {simpleParser} from "mailparser";
import path from "path";
import {fileURLToPath} from "url";
import {query} from "./db.js";
import {requireAdmin,signAdmin} from "./auth.js";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(), PORT=Number(process.env.PORT||3000), SMTP_PORT=Number(process.env.SMTP_PORT||2525);
const DOMAIN=(process.env.DOMAIN||"trstore.com").toLowerCase();
app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(__dirname,"public")));

const clean=v=>String(v||"").trim().toLowerCase();
const valid=u=>/^[a-z0-9][a-z0-9._-]{0,63}$/.test(u);
const mailbox=async u=>(await query("SELECT * FROM mailboxes WHERE username=$1",[u])).rows[0];

app.get("/health",async(_,res)=>{try{await query("select 1");res.json({ok:true,domain:DOMAIN})}catch{res.status(503).json({ok:false})}});
app.post("/api/auth/login",(req,res)=>{
 const {username,password}=req.body||{};
 if(username!==process.env.ADMIN_USER||password!==process.env.ADMIN_PASSWORD)return res.status(401).json({error:"Credenciais inválidas"});
 res.json({token:signAdmin()});
});
app.use("/api",requireAdmin);

app.get("/api/mailboxes",async(_,res)=>{
 const {rows}=await query("SELECT id,username,created_at FROM mailboxes ORDER BY username");
 res.json(rows.map(x=>({...x,email:`${x.username}@${DOMAIN}`})));
});
app.post("/api/mailboxes",async(req,res)=>{
 const username=clean(req.body?.username), password=String(req.body?.password||"");
 if(!valid(username))return res.status(400).json({error:"Nome inválido"});
 if(password.length<8)return res.status(400).json({error:"Senha mínima: 8 caracteres"});
 try{
  const hash=await bcrypt.hash(password,12);
  const {rows}=await query("INSERT INTO mailboxes(username,password_hash) VALUES($1,$2) RETURNING id,username,created_at",[username,hash]);
  res.status(201).json({...rows[0],email:`${username}@${DOMAIN}`});
 }catch(e){if(e.code==="23505")return res.status(409).json({error:"Caixa já existe"});res.status(500).json({error:"Erro ao criar caixa"});}
});
app.delete("/api/mailboxes/:username",async(req,res)=>{
 const r=await query("DELETE FROM mailboxes WHERE username=$1",[clean(req.params.username)]);
 if(!r.rowCount)return res.status(404).json({error:"Caixa não encontrada"});
 res.json({deleted:true});
});
app.get("/api/mailboxes/:username/messages",async(req,res)=>{
 const mb=await mailbox(clean(req.params.username)); if(!mb)return res.status(404).json({error:"Caixa não encontrada"});
 const limit=Math.min(Math.max(Number(req.query.limit||100),1),200);
 const {rows}=await query(`SELECT id,from_address,to_address,subject,text_body,html_body,received_at,is_read
 FROM messages WHERE mailbox_id=$1 ORDER BY received_at DESC LIMIT $2`,[mb.id,limit]);
 res.json(rows);
});
app.get("/api/messages/:id",async(req,res)=>{
 const {rows}=await query(`SELECT m.*,mb.username FROM messages m JOIN mailboxes mb ON mb.id=m.mailbox_id WHERE m.id=$1`,[req.params.id]);
 if(!rows[0])return res.status(404).json({error:"Mensagem não encontrada"});
 await query("UPDATE messages SET is_read=true WHERE id=$1",[req.params.id]);
 const m=rows[0]; res.json({...m,mailbox:`${m.username}@${DOMAIN}`});
});
app.delete("/api/messages/:id",async(req,res)=>{
 const r=await query("DELETE FROM messages WHERE id=$1",[req.params.id]);
 if(!r.rowCount)return res.status(404).json({error:"Mensagem não encontrada"});
 res.json({deleted:true});
});

app.listen(PORT,()=>console.log(`Web: ${PORT}`));

const smtp=new SMTPServer({
 authOptional:true,disabledCommands:["AUTH"],size:10485760,
 onRcptTo(address,session,cb){
  const [u,d]=address.address.toLowerCase().split("@");
  if(d!==DOMAIN||!u)return cb(new Error("Recipient not accepted"));
  mailbox(u).then(m=>{if(!m)return cb(new Error("Mailbox not found"));session.mailbox=m;session.recipient=`${u}@${d}`;cb()}).catch(cb);
 },
 onData(stream,session,cb){
  simpleParser(stream,{},async(err,p)=>{
   if(err)return cb(err);
   try{
    await query(`INSERT INTO messages(mailbox_id,message_id,from_address,to_address,subject,text_body,html_body,raw_size)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,[
      session.mailbox.id,p.messageId||null,p.from?.text||"",session.recipient,p.subject||"",
      p.text||"",typeof p.html==="string"?p.html:"",Number(stream.bytes||0)
    ]);
    cb();
   }catch(e){console.error(e);cb(e)}
  });
 }
});
smtp.listen(SMTP_PORT,"0.0.0.0",()=>console.log(`SMTP: ${SMTP_PORT} for ${DOMAIN}`));
