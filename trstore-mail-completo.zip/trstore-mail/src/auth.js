import jwt from "jsonwebtoken";
export function signAdmin(){return jwt.sign({role:"admin"},process.env.JWT_SECRET,{expiresIn:"12h"});}
export function requireAdmin(req,res,next){
 const h=req.headers.authorization||"";
 const token=h.startsWith("Bearer ")?h.slice(7):null;
 if(!token)return res.status(401).json({error:"Token ausente"});
 try{const p=jwt.verify(token,process.env.JWT_SECRET);if(p.role!=="admin")throw 0;req.user=p;next();}
 catch{return res.status(401).json({error:"Token inválido ou expirado"});}
}
