# TR Store Platform

Projeto inicial de uma plataforma de lojas digitais, inspirado na estrutura de SaaS/loja digital, com identidade própria TR Store.

Stack: React/Vite + Node.js/Express + PostgreSQL + Docker.

## Rodar
Copie `.env.example` para `.env`, altere os segredos e execute:

```bash
docker compose up -d --build
```

Painel: `http://SEU_IP:8080`

API: `http://SEU_IP:4000`

## GitHub

```bash
git init
git add .
git commit -m "TR Store Platform"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/tr-store-platform.git
git push -u origin main
```

Não envie `.env`.

## Nota
O checkout desta versão é demonstrativo e não cobra pagamentos. Para produção, conecte um gateway autorizado, webhooks, entrega segura de produtos, HTTPS, backups e controles de segurança.
